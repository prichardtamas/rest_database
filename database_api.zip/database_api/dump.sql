create database usersdb;
use usersdb;

create table users (
    id int  auto_increment primary key,
    firstname varchar(100) not null,
    lastname varchar(100) not null,
    city varchar(100) not null,
    address varchar(100) not null,
    phone varchar(100) not null,
    email varchar(100) not null,
    gender varchar(100) not null
);